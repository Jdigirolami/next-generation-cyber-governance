# -*- encoding: utf-8 -*-

import pandas as pd

from datetime import datetime as dt
from flask import jsonify, render_template, redirect, request, url_for
from flask_login import current_user, login_required, login_user, logout_user
from sqlalchemy import func, or_

from apps import db, login_manager
from apps.authentication import blueprint
from apps.authentication.forms import LoginForm, RegisterForm
from apps.authentication.models import Users
from apps.authentication.util import hash_pass, verify_pass
from apps.dashboard.models import Controls, Risks, Threats
from apps.utils import round_num


@blueprint.route('/')
def route_default():

    return redirect(url_for('authentication_blueprint.login'))


@blueprint.route('/login', methods=['GET', 'POST'])
def login():

    form = LoginForm(request.form)
    if 'login' in request.form:
        # read form data
        username = request.form['username']
        password = request.form['password']

        # Locate user
        user = Users.query.filter(
            func.lower(Users.username)==username.lower()
        ).first()

        # Check the password
        if user and verify_pass(password, user.password):
            login_user(user)
            return redirect(url_for('authentication_blueprint.route_default'))

        # Something (user or pass) is not ok
        return render_template(
            'accounts/login.html',
            msg='Wrong user or password',
            form=form
        )

    if not current_user.is_authenticated:
        return render_template(
            'accounts/login.html',
            form=form
        )

    return redirect(url_for('dashboard_blueprint.dashboard'))


@blueprint.route('/register', methods=['GET', 'POST'])
def register():

    form = RegisterForm(request.form)
    if 'register' in request.form:
        email = request.form['email'].strip()
        firstname = request.form['firstname'].strip()
        lastname = request.form['lastname'].strip()
        password = request.form['password']
        username = request.form['username'].strip()

        # Validate username and email
        user = Users.query.filter(
            or_(
                func.lower(Users.email)==email.lower(),
                func.lower(Users.username)==username.lower()
            )
        ).first()
        if user:
            msg = ''
            if user.username.lower() == username.lower():
                msg = 'Username already registered'
            else:
                msg = 'Email already registered'

            return render_template(
                'accounts/register.html',
                msg=msg,
                success=False,
                form=form
            )

        user = Users(
            email=email,
            firstname=firstname,
            lastname=lastname,
            password=password,
            username=username
        )
        db.session.add(user)
        db.session.commit()

        # Insert default Controls
        to_controls = []
        try:
            df_controls = pd.read_csv('apps/static/files/controls.csv')
            for i, d in df_controls.iterrows():
                to_controls.append(Controls(
                    category=d.category,
                    date_created=dt.now(),
                    function=d.function,
                    status=d.status,
                    subcategory=d.subcategory,
                    subcategory_id=d.subcategory_id,
                    user_id=user.id
                ))
        except:
            pass

        # Insert default risks
        to_risks = []
        try:
            df_risks = pd.read_csv('apps/static/files/risks.csv')
            for i, d in df_risks.iterrows():
                impact = round_num(d.impact)
                likelihood = int(round_num(d.likelihood))
                ale = round_num(impact * likelihood)
                to_risks.append(Risks(
                    ale=ale,
                    date_created=dt.now(),
                    impact=impact,
                    likelihood=likelihood,
                    risk=d.risk,
                    user_id=user.id
                ))
        except:
            pass

        # Insert default threats
        to_threats = []
        try:
            df_threats = pd.read_csv('apps/static/files/threats.csv')
            for i, d in df_threats.iterrows():
                to_threats.append(Threats(
                    date_created=dt.now(),
                    linked_controls=d.linked_controls,
                    mitre_tactic=d.mitre_tactic,
                    threat=d.threat,
                    user_id=user.id
                ))
        except:
            pass

        to_save = to_controls + to_risks + to_threats
        if any(to_save):
            db.session.add_all(to_save)
            db.session.commit()

        return render_template(
            'accounts/register.html',
            msg='User created please <a href="/login">login</a>',
            success=True,
            form=form
        )

    else:
        return render_template('accounts/register.html', form=form)


@blueprint.route('/change-password', methods=['POST'])
@login_required
def change_password():

    # Get data from request
    _json = request.get_json(force=True)

    _return = {'status': 500}

    if verify_pass(_json.get('old_password'), current_user.password):
        _return['status'] = 200
        _return['message'] = 'Password successfully changed.'

        user = Users.query.get(current_user.id)
        user.password = hash_pass(_json['new_password'])
        db.session.commit()

        current_user.password = user.password
    else:
        _return['message'] = 'Invalid password.'

    return jsonify(_return)


@blueprint.route('/logout')
def logout():

    logout_user()
    return redirect(url_for('authentication_blueprint.login'))


# Errors

@login_manager.unauthorized_handler
def unauthorized_handler():

    return render_template('dashboard/page-403.html'), 403


@blueprint.errorhandler(403)
def access_forbidden(error):

    return render_template('dashboard/page-403.html'), 403


@blueprint.errorhandler(404)
def not_found_error(error):

    return render_template('dashboard/page-404.html'), 404


@blueprint.errorhandler(500)
def internal_error(error):

    return render_template('dashboard/page-500.html'), 500
