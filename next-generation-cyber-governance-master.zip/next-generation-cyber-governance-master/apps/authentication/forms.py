# -*- encoding: utf-8 -*-

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import Email, DataRequired


class LoginForm(FlaskForm):

    username = StringField(
        'Username',
        id='username_login',
        validators=[DataRequired()]
    )
    password = PasswordField(
        'Password',
        id='pwd_login',
        validators=[DataRequired()]
    )


class RegisterForm(FlaskForm):

    email = StringField(
        'Email',
        id='email_create',
        validators=[DataRequired(), Email()]
    )
    firstname = StringField(
        'Firstname',
        id='firstname_create',
        validators=[DataRequired()]
    )
    lastname = StringField(
        'Lastname',
        id='lastname_create',
        validators=[DataRequired()]
    )
    password = PasswordField(
        'Password',
        id='pwd_create',
        validators=[DataRequired()]
    )
    username = StringField(
        'Username',
        id='username_create',
        validators=[DataRequired()]
    )
