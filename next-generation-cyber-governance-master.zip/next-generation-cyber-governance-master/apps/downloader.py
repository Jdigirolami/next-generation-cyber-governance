# -*- encoding: utf-8 -*-

import os
import pandas as pd
import re

from flask import Blueprint, jsonify, make_response, request, send_file
from flask_login import current_user, login_required
from io import BytesIO


blueprint = Blueprint(
    'downloader_blueprint',
    __name__,
    url_prefix=''
)


@blueprint.route('/download', methods=['POST'])
@login_required
def download():

    # Get data from request
    _json = request.get_json(force=True)

    document = _json.get('document') or ''
    _id = _json.get('id') or ''
    _type = _json.get('type') or ''

    _return = {'status': 200}

    response = None
    if _type == 'template':
        response = download_template(_id)

    if type(response) == dict:
        _return = response
    elif response:
        return response

    return jsonify(_return), 299


def download_template(_id=''):

    if _id == 'download-template':
        data = [
            'column1,column2',
            'value1,value2'
        ]
    else:
        data = []

    response = make_response('\n'.join(data))
    cd = f'attachment; filename={_id}.csv'
    response.headers['Content-Disposition'] = cd
    response.mimetype = 'text/csv'
    return response
