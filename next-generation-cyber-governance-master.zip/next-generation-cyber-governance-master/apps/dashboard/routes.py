# -*- encoding: utf-8 -*-

from datetime import datetime as dt
from flask import jsonify, render_template, request
from flask_login import current_user, login_required
from jinja2 import TemplateNotFound

from . import blueprint
from .models import Controls, Risks, Threats
from apps import db
from apps.utils import round_num


@blueprint.route('/dashboard')
@login_required
def dashboard():

    # Get Controls
    controls = Controls.query.filter(
        Controls.user_id==current_user.id
    ).all()
    controls = [d.as_dict() for d in controls]

    return render_template(
        'dashboard/list.html',
        segment='dashboard',
        title='Dashboard',
        controls=controls
    )


@blueprint.route('/<template>')
@login_required
def route_template(template):

    try:
        if not template.endswith('.html'):
            template += '.html'

        # Detect the current page
        segment = get_segment(request)

        # Serve the file (if exists) from app/templates/dashboard/FILE.html
        return render_template("dashboard/" + template, segment=segment)

    except TemplateNotFound:
        return render_template('dashboard/page-404.html'), 404

    except:
        return render_template('dashboard/page-500.html'), 500


# Helper - Extract current page name from request
def get_segment(request):

    try:
        return request.path.split('/')[-1] or 'dashboard'
    except:
        return None


@blueprint.route('/controls', methods=['POST'])
@login_required
def create_controls():

    # Get data from request
    _json = request.get_json(force=True)

    _return = {'status': 200}

    # Insert to Controls
    db.session.add(Controls(
        category=_json.get('category') or '',
        date_created=dt.now(),
        function=_json.get('function') or '',
        status=_json.get('status') or 'Not Started',
        subcategory=_json.get('subcategory') or '',
        subcategory_id=_json.get('subcategory_id') or '',
        user_id=current_user.id
    ))
    db.session.commit()

    _return['message'] = 'Document successfully saved.'

    return jsonify(_return)


@blueprint.route('/controls')
@login_required
def get_controls():

    # Get data from request
    _json = dict(request.args)

    _return = {}

    # Pagination
    limit = int(_json.get('limit') or 50)
    page = int(_json.get('page') or 1)

    # Get Controls
    items = Controls.query.filter(
        Controls.user_id==current_user.id
    ).order_by(
        Controls.id
    ).paginate(
        error_out=False,
        page=page,
        per_page=limit
    )
    _items = [d.as_dict() for d in items.items]

    _return['count'] = ((page-1) * limit) + len(_items)
    _return['limit'] = limit
    _return['page'] = page
    _return['return'] = _items
    _return['total_items'] = items.total

    return jsonify(_return)


@blueprint.route('/controls', methods=['PUT'])
@login_required
def update_controls():

    # Get data from request
    _json = request.get_json(force=True)

    _return = {'status': 200}

    _id = _json.get('id')

    # Check if exists
    document = Controls.query.get(_id)
    if document:
        # Update in Controls
        for k in (
            'category', 'function', 'status', 'subcategory', 'subcategory_id'
        ):
            if k in _json:
                setattr(document, k, _json[k])

        document.date_updated = dt.now()
        db.session.commit()

        _return['message'] = 'Document successfully updated.'
    else:
        _return['status'] = 500
        _return['message'] = 'Document not found.'

    return jsonify(_return)


@blueprint.route('/controls/<int:id>', methods=['DELETE'])
@login_required
def delete_controls(id):

    _return = {'status': 200}

    # Check if exists
    document = Controls.query.get(id)
    if document:
        # Delete from Controls
        db.session.delete(document)
        db.session.commit()

        _return['message'] = 'Document successfully deleted.'
    else:
        _return['status'] = 500
        _return['message'] = 'Document not found.'

    return jsonify(_return)


@blueprint.route('/risks', methods=['POST'])
@login_required
def create_risks():

    # Get data from request
    _json = request.get_json(force=True)

    _return = {'status': 200}

    # Get impact and likelihood for ALE computation
    impact = round_num(_json.get('impact'))
    likelihood = int(round_num(_json.get('likelihood')))

    # Insert to Risks
    db.session.add(Risks(
        ale=round_num(impact * likelihood),
        date_created=dt.now(),
        risk=_json.get('risk') or '',
        impact=impact,
        likelihood=likelihood,
        user_id=current_user.id
    ))
    db.session.commit()

    _return['message'] = 'Document successfully saved.'

    return jsonify(_return)


@blueprint.route('/risks')
@login_required
def get_risks():

    # Get data from request
    _json = dict(request.args)

    _return = {}

    # Pagination
    limit = int(_json.get('limit') or 50)
    page = int(_json.get('page') or 1)

    # Get Risks
    items = Risks.query.filter(
        Risks.user_id==current_user.id
    ).order_by(
        Risks.id
    ).paginate(
        error_out=False,
        page=page,
        per_page=limit
    )
    _items = [d.as_dict() for d in items.items]

    _return['count'] = ((page-1) * limit) + len(_items)
    _return['limit'] = limit
    _return['page'] = page
    _return['return'] = _items
    _return['total_items'] = items.total

    return jsonify(_return)


@blueprint.route('/risks', methods=['PUT'])
@login_required
def update_risks():

    # Get data from request
    _json = request.get_json(force=True)

    _return = {'status': 200}

    _id = _json.get('id')

    # Check if exists
    document = Risks.query.get(_id)
    if document:
        # Compute for ALE if there was an update in either impact or likelihood
        if 'impact' in _json or 'likelihood' in _json:
            impact = _json.get('impact') or document.impact
            _json['impact'] = round_num(impact)
            likelihood = _json.get('likelihood') or document.likelihood
            _json['likelihood'] = int(round_num(likelihood))
            _json['ale'] = round_num(_json['impact'] * _json['likelihood'])

        # Update in Risks
        for k in ('ale', 'impact', 'likelihood', 'risk'):
            if k in _json:
                setattr(document, k, _json[k])

        document.date_updated = dt.now()
        db.session.commit()

        _return['message'] = 'Document successfully updated.'
    else:
        _return['status'] = 500
        _return['message'] = 'Document not found.'

    return jsonify(_return)


@blueprint.route('/risks/<int:id>', methods=['DELETE'])
@login_required
def delete_risks(id):

    _return = {'status': 200}

    # Check if exists
    document = Risks.query.get(id)
    if document:
        # Delete from Risks
        db.session.delete(document)
        db.session.commit()

        _return['message'] = 'Document successfully deleted.'
    else:
        _return['status'] = 500
        _return['message'] = 'Document not found.'

    return jsonify(_return)


@blueprint.route('/threats', methods=['POST'])
@login_required
def create_threats():

    # Get data from request
    _json = request.get_json(force=True)

    _return = {'status': 200}

    # Insert to Threats
    db.session.add(Threats(
        date_created=dt.now(),
        linked_controls=_json.get('linked_controls') or '',
        mitre_tactic=_json.get('mitre_tactic') or '',
        threat=_json.get('threat') or '',
        user_id=current_user.id
    ))
    db.session.commit()

    _return['message'] = 'Document successfully saved.'

    return jsonify(_return)


@blueprint.route('/threats')
@login_required
def get_threats():

    # Get data from request
    _json = dict(request.args)

    _return = {}

    # Pagination
    limit = int(_json.get('limit') or 50)
    page = int(_json.get('page') or 1)

    # Get Threats
    items = Threats.query.filter(
        Threats.user_id==current_user.id
    ).order_by(
        Threats.id
    ).paginate(
        error_out=False,
        page=page,
        per_page=limit
    )
    _items = [d.as_dict() for d in items.items]

    _return['count'] = ((page-1) * limit) + len(_items)
    _return['limit'] = limit
    _return['page'] = page
    _return['return'] = _items
    _return['total_items'] = items.total

    return jsonify(_return)


@blueprint.route('/threats', methods=['PUT'])
@login_required
def update_threats():

    # Get data from request
    _json = request.get_json(force=True)

    _return = {'status': 200}

    _id = _json.get('id')

    # Check if exists
    document = Threats.query.get(_id)
    if document:
        # Update in Threats
        for k in ('linked_controls', 'mitre_tactic', 'threat'):
            if k in _json:
                setattr(document, k, _json[k])

        document.date_updated = dt.now()
        db.session.commit()

        _return['message'] = 'Document successfully updated.'
    else:
        _return['status'] = 500
        _return['message'] = 'Document not found.'

    return jsonify(_return)


@blueprint.route('/threats/<int:id>', methods=['DELETE'])
@login_required
def delete_threats(id):

    _return = {'status': 200}

    # Check if exists
    document = Threats.query.get(id)
    if document:
        # Delete from Threats
        db.session.delete(document)
        db.session.commit()

        _return['message'] = 'Document successfully deleted.'
    else:
        _return['status'] = 500
        _return['message'] = 'Document not found.'

    return jsonify(_return)