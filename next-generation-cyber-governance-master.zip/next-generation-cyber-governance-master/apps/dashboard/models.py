# -*- encoding: utf-8 -*-

from apps import db
from sqlalchemy.orm import relationship


class Controls(db.Model):

    __tablename__ = 'Controls'

    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String)
    date_created = db.Column(db.DateTime)
    date_updated = db.Column(db.DateTime)
    function = db.Column(db.String)
    status = db.Column(db.String)
    subcategory = db.Column(db.String)
    subcategory_id = db.Column(db.String)
    user_id = db.Column(
        db.Integer,
        db.ForeignKey('Users.id', ondelete='CASCADE')
    )

    user = relationship('Users', foreign_keys=user_id)


    def __repr__(self):

        return str(self.id)


    def as_dict(self):

        return {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }


class Risks(db.Model):

    __tablename__ = 'Risks'

    id = db.Column(db.Integer, primary_key=True)
    ale = db.Column(db.Float, default=0)
    date_created = db.Column(db.DateTime)
    date_updated = db.Column(db.DateTime)
    impact = db.Column(db.Float, default=0)
    likelihood = db.Column(db.Integer, default=0)
    risk = db.Column(db.String)
    user_id = db.Column(
        db.Integer,
        db.ForeignKey('Users.id', ondelete='CASCADE')
    )

    user = relationship('Users', foreign_keys=user_id)


    def __repr__(self):

        return str(self.id)


    def as_dict(self):

        return {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }


class Threats(db.Model):

    __tablename__ = 'Threats'

    id = db.Column(db.Integer, primary_key=True)
    date_created = db.Column(db.DateTime)
    date_updated = db.Column(db.DateTime)
    linked_controls = db.Column(db.String)
    mitre_tactic = db.Column(db.String)
    threat = db.Column(db.String)
    user_id = db.Column(
        db.Integer,
        db.ForeignKey('Users.id', ondelete='CASCADE')
    )

    user = relationship('Users', foreign_keys=user_id)


    def __repr__(self):

        return str(self.id)


    def as_dict(self):

        return {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }