# -*- encoding: utf-8 -*-

from flask import jsonify, render_template, request
from flask_login import current_user, login_required

from apps import db
from apps.settings import blueprint


@blueprint.route('/settings')
@login_required
def get_settings():

    return render_template(
        'settings/list.html',
        segment='settings-list',
        title='Settings'
    )


# ----- Account ----- #

@blueprint.route('/settings/account')
@login_required
def get_account():

    _return = {'status': 200}
    _return['return'] = [current_user.as_dict()]

    return jsonify(_return)


@blueprint.route('/settings/account', methods=['PUT'])
@login_required
def update_account():

    # Get data from request
    _json = request.get_json(force=True)

    _return = {'status': 200}

    current_user.firstname = _json.get('firstname')
    current_user.lastname = _json.get('lastname')
    current_user.email = _json.get('email')
    db.session.commit()

    _return['message'] = 'Account successfully updated.'

    return jsonify(_return)

# ----- End of Account ----- #
